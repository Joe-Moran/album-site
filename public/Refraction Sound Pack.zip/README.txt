REFRACTION SOUND PACK:
    � Ableton Presets
        - audio effect racks � 4
    � Audio Samples
        - Tunes (unused samples of some PSA music I dig) � 4
        - Voices (unused samples of some PSA voices mostly about drugs) � 6
    � Omnisphere Patches
        - Leads � 2
        - Multi-Use (rhythmic, FX, noise, etc.) � 5
        - Pads � 3
        - Synth Bass � 1
    � Prophet REV2 Patches
        - Leads � 2
        - Multi-Use (FX and some sweet shit to play chords with) � 2
        - Pads � 2





Howdy.

Thank you so much for your support and love and whatever else you�ve been secretly sending me without my knowing. Sound design is a huge part of my creative process and I felt I needed to share some of said sounds with folks like yourself. I hope� at the very least�you find inspiration within these files, but if you feel these sounds are uninspiring or dull or pointless, then good on you! Sometimes the best musicians, composers, or producers require a hell of a picky ear to translate or find inspiration from a sound or song, so I�m content with the reality that maybe I�m helping you not sound as shitty as I do. Either way, I hope you are writing some sick fucking jams and having as much fun as I did putting together my album �Refraction.�

Thanks for listening!

Love,

xRGB
